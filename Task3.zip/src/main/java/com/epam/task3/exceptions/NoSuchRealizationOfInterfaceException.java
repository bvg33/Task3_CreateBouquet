package com.epam.task3.exceptions;

public class NoSuchRealizationOfInterfaceException extends Exception {
    public NoSuchRealizationOfInterfaceException(String message) {
        super(message);
    }
}
