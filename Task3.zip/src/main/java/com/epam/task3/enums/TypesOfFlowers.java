package com.epam.task3.enums;

public enum TypesOfFlowers {
    CHAMOMILE, ROSE, LILY
}
