package com.epam.task3.enums;

public enum TypesOfResultPrinters {
    CONSOLE, FILE
}
